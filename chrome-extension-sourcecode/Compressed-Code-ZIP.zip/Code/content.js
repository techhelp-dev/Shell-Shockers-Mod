alert('A bookmark version of this theme is coming soon!');

alert('PSST! You get extra mod settings and cool features by going to the puzzle piece at the top-right of your screen, and clicking on our extension, enjoy!');

document.title = "Dark Mode";
var style = document.createElement("link");
style.rel = "stylesheet";
style.href = "https://colesprojects.ml/SHELL_SHOCKERS_THEME/code.css";
document.head.appendChild(style);



var gamestyle = document.createElement("link");
gamestyle.rel = "stylesheet";
gamestyle.href = "https://colesprojects.ml/SHELL_SHOCKERS_THEME/game.css";
document.head.appendChild(gamestyle);


